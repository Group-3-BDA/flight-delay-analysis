"""Gold-layer output writers."""

from pyspark.sql import DataFrame


def write_gold_outputs(
    fact_flights_df,
    dim_airline_df,
    dim_airport_df,
    dim_date_df,
    dim_route_df,
    ml_dataset_df,
    config,
):
    dim_date_df.write.mode(config.output_mode).parquet(
        config.dim_date_path
    )
    dim_airline_df.write.mode(config.output_mode).parquet(
        config.dim_airline_path
    )
    dim_airport_df.write.mode(config.output_mode).parquet(
        config.dim_airport_path
    )
    dim_route_df.write.mode(config.output_mode).parquet(
        config.dim_route_path
    )

    (
        fact_flights_df
        .write
        .mode(config.output_mode)
        .partitionBy("Year", "Month")
        .parquet(config.fact_flights_path)
    )

    (
        ml_dataset_df
        .write
        .mode(config.output_mode)
        .partitionBy("Year", "Month")
        .parquet(config.ml_dataset_path)
    )
